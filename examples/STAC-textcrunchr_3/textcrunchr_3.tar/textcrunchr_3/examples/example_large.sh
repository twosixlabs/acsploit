#!/bin/sh
../challenge_program/bin/textcrunchrhost_1 large.zip
